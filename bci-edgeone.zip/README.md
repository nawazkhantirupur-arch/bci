# BCI EXPRESS - EdgeOne Pages-ல் Deploy செய்வது (PHP / MySQL தேவையில்லை)

இந்த package-ல் 2 கோப்புகள் மட்டுமே:

```
index.html                              <- முழு website (billing, B2B/B2C, wallet, users, Delhivery UI)
edge-functions/api/[[default]].js       <- server பகுதி (login, wallet, Razorpay, Delhivery, data)
```

ஏன் 2 கோப்புகள்? Razorpay Key Secret, Delhivery API Token, password சரிபார்ப்பு,
wallet balance ஆகியவை HTML-ல் இருந்தால் யார் வேண்டுமானாலும் page source-ல் பார்த்து
திருடலாம் / balance-ஐ மாற்றலாம். அதனால் இவை மட்டும் EdgeOne-ன் server function-ல் இருக்கும்.
Data (users, wallet, invoices) EdgeOne KV storage-ல் சேமிக்கப்படும் - எல்லா location-லும் ஒரே data.

## படி 1 - GitHub-ல் upload (எளிய வழி)
1. github.com-ல் ஒரு புதிய (Private) repository உருவாக்கவும்.
2. "Add file -> Upload files" -> `index.html` மற்றும் `edge-functions` folder-ஐ அப்படியே drag & drop செய்யவும்.
   (folder அமைப்பு மாறக்கூடாது: `edge-functions/api/[[default]].js`)
3. Commit செய்யவும்.

(மாற்று: EdgeOne Pages-ன் "Direct Upload"-ல் இதே folder-ஐ upload செய்து பார்க்கலாம்.
 deploy ஆன பிறகு `உங்கள்-site/api/auth.php?action=status` திறந்தால் JSON வரவில்லை என்றால்
 functions upload ஆகவில்லை - அப்போது GitHub வழியைப் பயன்படுத்தவும்.)

## படி 2 - EdgeOne Pages-ல் Project
1. EdgeOne Pages -> Create project -> Import Git repository -> உங்கள் repo.
2. Framework: Other / None. Build command: காலியாக. (Static project)
3. Deploy.

## படி 3 - KV storage bind செய்யவும் (மிக முக்கியம்)
1. Project -> KV Storage -> Apply/Create namespace.
2. Project-உடன் bind செய்யும்போது **Variable name = `bci_kv`** என்று சரியாக எழுதவும்.

## படி 4 - Environment Variables (Project Settings)
| பெயர் | மதிப்பு |
|---|---|
| `SESSION_SECRET` | நீளமான random எழுத்துகள் (40+). யாருக்கும் சொல்ல வேண்டாம் |
| `SETUP_KEY` | நீங்களே தேர்வு செய்யும் ரகசிய சொல் (முதல் admin உருவாக்க மட்டும்) |
| `RAZORPAY_KEY_ID` | **புதிதாக Regenerate செய்த** Razorpay Key ID |
| `RAZORPAY_KEY_SECRET` | **புதிதாக Regenerate செய்த** Key Secret |
| `DELHIVERY_TOKEN` | Delhivery API token (regenerate செய்தது) |
| `DELHIVERY_CLIENT` | Delhivery-ல் உங்கள் client/account பெயர் |
| `DELHIVERY_PICKUP` | Delhivery-ல் registered pickup/warehouse பெயர் |

Razorpay / Delhivery பின்னர் சேர்க்கலாம். SESSION_SECRET மற்றும் SETUP_KEY மட்டும் முதலில் வேண்டும்.
மாற்றிய பிறகு **Redeploy** செய்யவும்.

## படி 5 - முதல் Admin
1. உங்கள் site-ஐ திறந்தால் "First-time Setup" வரும்.
2. SETUP_KEY, உங்கள் Admin username/password (8+ எழுத்து) கொடுத்து உருவாக்கவும்.
   Default password எதுவும் இல்லை.
3. Admin -> Rate Master tab -> "Delhivery API" பெட்டியில் ✅/❌ நிலை தெரியும்.

## பயன்பாடு
- Vendors/Users: login page-ல் "Create Account" -> Admin "Vendors/Users" tab-ல் Approve/Reject.
- Wallet: vendor தாங்களே 💰 பொத்தான் -> Razorpay மூலம் recharge. Booking-ல் தொகை தானாக கழியும்.
  Razorpay இல்லாதபோது Admin "+ / -" மூலம் கைமுறை recharge.
- Margin (10-20%): Admin-க்கு மட்டும் தெரியும்; கணக்கீடு server-ல்.
- Delhivery: B2C Courier-ல் Delhivery partner தேர்ந்து invoice save -> "Auto Order Create" -> Label/Track.

## கட்டாயம் தெரிந்துகொள்ள வேண்டியவை
1. **Razorpay Live**: Razorpay Dashboard-ல் உங்கள் website domain-ஐ அனுமதிக்க வேண்டியிருக்கலாம்.
   முதலில் Test keys-ல் சோதிக்கவும்.
2. **KV 1 நிமிடம் தாமதம்**: ஒரு location-ல் செய்த மாற்றம் (Approve, wallet credit) மற்ற location-ல்
   அதிகபட்சம் ~60 வினாடி கழித்து தெரியலாம். Wallet குறியீடு credit திருடு போகாதபடி வடிவமைக்கப்பட்டுள்ளது;
   ஆனால் ஒரே நொடியில் வெவ்வேறு இடங்களிலிருந்து booking செய்தால் மிக அரிதாக balance-ஐ தாண்டி செலவாகலாம்.
3. Password மறந்தால்: Admin "Reset PW". Email மூலம் reset வசதி இல்லை.
4. பழைய PHP/Ezyro தரவு இங்கு மாறாது - இது புதிய system.
5. Delhivery "Auto Order Create" உங்கள் account-உடன் முதலில் ஒரு சோதனை order மூலம் சரிபார்க்கவும்.

---
# புதிய அம்சங்கள் (Delhivery Ship)

**🚚 Delhivery Ship tab** (Admin + Users/Vendors அனைவருக்கும்) - ஒரே இடத்தில்:
1. **Get Rate** - Delhivery API-ல் இருந்து live கட்டணம் + நமது margin (10-30%) தானாக + GST. Vendors-க்கு margin தெரியாது.
2. **Book Shipment** - Delhivery-ல் Order + Manifest உருவாக்கி AWB (waybill) பெறும். Vendor wallet-ல் இருந்து தொகை தானாக கழியும்; Delhivery order தோல்வியடைந்தால் எதுவும் கழியாது.
3. **Shipping Label** - PDF label.
4. **Pickup Request** - தேதி/நேரம்/packages கொடுத்து Delhivery pickup கோரிக்கை.
5. **Track** - shipment நிலை.

**Admin-க்கு Notifications (🔔):** புதிய account request, புதிய invoice, புதிய Delhivery shipment, Pickup request, Wallet recharge.

**Admin செய்ய வேண்டியவை:**
- Rate Master -> "Delhivery Shipping Margin" (10-30%) நிர்ணயிக்கவும்.
- Vendors/Users -> ஒவ்வொரு vendor-ன் "📦 ... edit" -> அவர்களின் **Delhivery pickup location (warehouse) பெயர்** மற்றும் pickup pincode. (Delhivery One-ல் registered ஆன அதே பெயர்.) காலியாக இருந்தால் `DELHIVERY_PICKUP` (default) பயன்படும்.
- Delhivery கணக்கீடு: `gross_amount` (GST-க்கு முன்) எடுத்து margin சேர்த்து, பின் 18% GST சேர்க்கப்படுகிறது.

## பல Vendors / பல Locations - Pickup Address (Delhivery Warehouse)
- **🚚 Delhivery Ship tab -> "📍 My Pickup Address"**: ஒவ்வொரு Vendor-ம் தங்கள் pickup முகவரியை (contact person, mobile, address, city, state, pincode) சேமிக்கலாம். சேமித்ததும் அது **தானாக Delhivery-ல் warehouse ஆக register ஆகும்** (பெயர்: `BCI_<USERNAME>`). மீண்டும் சேமித்தால் Delhivery-ல் update ஆகும்.
- Vendor தன் Pickup Address சேமிக்கும் வரை Shipment book / Pickup request செய்ய முடியாது. Shipment & Pickup எப்போதும் அந்த Vendor-ன் சொந்த warehouse-லிருந்தே.
- Admin வேறு Vendor-க்காகவும் முகவரியை register செய்யலாம் ("Admin: Vendor username" கட்டம்).
- Admin-க்கு 🔔 notification: "Pickup address registered/updated".
- `registered_name` = `DELHIVERY_CLIENT` env value (Delhivery-ல் உங்கள் client பெயருடன் சரியாக பொருந்த வேண்டும்).

## சரிசெய்தல் (Admin பட்டியலில் users வரவில்லை / Razorpay "Authentication failed")
- **Users பட்டியல்**: இப்போது தனி user index பயன்படுத்தப்படுகிறது (KV list() வேலை செய்யாவிட்டாலும் வரும்). பழைய கணக்கு பட்டியலில் இல்லையெனில்: Vendors/Users tab -> "🔎 Find & add to list" -> அவர்களின் username கொடுக்கவும்.
- **Rate Master -> Delhivery API பெட்டியில் System status**: KV list ✅/❌, User index எண்ணிக்கை, Razorpay keys (mode, நீளம், காரணம்) தெரியும்.
- **Razorpay "Authentication failed"**: Key ID & Key Secret இரண்டும் ஒரே mode-ல் (`rzp_test_` அல்லது `rzp_live_`) இருக்க வேண்டும்; Secret-க்கு பதிலாக ID போடக்கூடாது; இடைவெளி (space) இருக்கக்கூடாது (தானாக trim செய்யப்படும்); Live keys, Razorpay-ல் Live mode activate ஆன பின்னரே. Secret மறந்தால் புதிய key உருவாக்கவும். மாற்றிய பின் Redeploy.

---
# 🚀 Shadowfax (இரண்டாவது Courier Partner)
Delhivery-க்கு எந்த மாற்றமும் இல்லை; Shadowfax தனி tab + தனி backend பகுதி.

**Environment Variables (EdgeOne):**
- `SHADOWFAX_TOKEN` - Shadowfax API token (SFX 360 portal-ல் உருவாக்கியது). **ஒருபோதும் GitHub / chat-ல் எழுத வேண்டாம்.**
- `SHADOWFAX_BASE` (விருப்பம்) - சோதனைக்கு `https://dale.staging.shadowfax.in/api`; காலியாக இருந்தால் Production (`https://dale.shadowfax.in/api`).

**Admin:** Rate Master -> "🚀 Shadowfax Rate Master": 5 category-க்கான Base rate / extra step rate, base & step kg, COD, volumetric divisor, **Margin (10-40%)**. (Shadowfax-க்கு public live-rate API இல்லை, அதனால் உங்கள் Shadowfax rate card இங்கே நிரப்ப வேண்டும்.) Token நிலை (✅/❌) அதே பெட்டியில் தெரியும்.

**Users/Vendors:** 🚀 Shadowfax Ship tab -> My Pickup Address சேமிக்கவும் -> Get Rate (margin தெரியாது) -> Book Shipment (wallet-ல் இருந்து கழியும்) -> Label / Track. Admin-க்கு 🔔 notification வரும்.

**வரம்புகள்:** ₹50,000+ மதிப்புள்ள shipment (e-way bill) தடுக்கப்படும்; தனி Cancel / Pickup-request இல்லை (Pickup date order-லேயே கொடுக்கலாம்).

---
# 🛒 Ekart (மூன்றாவது Courier Partner) + 📦 All Shipments
Delhivery, Shadowfax-க்கு எந்த மாற்றமும் இல்லை; Ekart தனி tab + தனி backend பகுதி.

**Environment Variables (EdgeOne):**
- `EKART_CLIENT_ID`, `EKART_USERNAME`, `EKART_PASSWORD` - Ekart Elite கணக்கு விவரங்கள் (அல்லது முன்பே வழங்கப்பட்ட `EKART_TOKEN`).
- `EKART_BASE` (விருப்பம்) - default `https://app.elite.ekartlogistics.in`.
- `EKART_SELLER_GSTIN` (விருப்பம்) - Vendor-க்கு GSTIN இல்லையெனில் பயன்படும் default seller GSTIN.

**Admin:** Rate Master -> "🛒 Ekart Settings": default Margin (10-40%) + login நிலை (✅/❌). Rate, Ekart live estimate API-ல் இருந்து வரும்; அதனுடன் margin + GST சேரும்.

**Users/Vendors:** 🛒 Ekart Ship tab -> My Pickup Address (Ekart-ல் தானாக register: `BCI_<USERNAME>`) -> Get Live Rate (margin தெரியாது) -> Book Shipment (wallet-ல் கழியும்) -> Label (PDF), Manifest, Track.

**📦 All Shipments tab:** Delhivery + Shadowfax + Ekart அனைத்து shipments ஒரே பட்டியலில்; courier வடிகட்டி; Label/Track அந்தந்த courier-க்கு.

**வரம்புகள்:** ₹50,000+ (e-way bill) தடுக்கப்படும்; Cancel இல்லை. முகவரியை மாற்றி சேமித்தால் Ekart-ல் புதிய alias (`BCI_<USER>_2`...) உருவாகும்.
